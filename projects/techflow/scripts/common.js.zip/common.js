/*Doucment resize Function*/
$(window).resize(function () {
  fixedFooter();
})
/*Docuemnt load function*/
$(window).load(function () {
  fixedFooter()
  $('.loader').fadeOut();

/*Maximum height li*/
var liMaxHeight = -1;
var node;
$(".servicelistbox ul li").each(function(index) {
    if ($(this).outerHeight() > liMaxHeight) {
 liMaxHeight = $(this).outerHeight();
 node = index;
    }
});
//alert("li with index "+node+" has height "+liMaxHeight);
$('.servicelistbox ul li').css('min-height',liMaxHeight+1);
/*Maximum height li*/

})
/*Ready Funtion*/
$(function () {
  fixedFooter();

  /*Back to top Function start*/
  $('body').append('<div class="scrollTop"><a href="javascript:void(0)"></a></div>');
//  $('body').append('<div id="empDtlError" class="overlay-box"><div class="seisson-message error"><span></span> Overlay id is not defined </div></div>');
  $(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
      $('.scrollTop').fadeIn();
    } else {
      $('.scrollTop').fadeOut();
    }
  });
  $(document).on('click', '.scrollTop a', function () {
    $('body,html').animate({scrollTop: 0}, 800);
  });
  
  /*accordion start*/
  $('.accordion dl dt').click(function () {
    var trigger = $(this);
    var target = trigger.next('dd');
    if (target.css('display') == 'none')
    {
      $('.accordion dl').removeClass('active')
      $('.accordion dl dd').slideUp();
      target.slideDown();
      trigger.parents('dl').addClass('active');
    }
    else
    {
      $('.accordion dl').removeClass('active')
      $('.accordion dl dd').slideUp();
    }
  });
  /*accordion start*/
  /*mobile Navigation*/
  $('.toggle-btn').click(function () {
    if ($('.wrapper').hasClass('opened'))
    {
      $('.wrapper').removeClass('opened');
    }
    else
    {
      $('.wrapper').addClass('opened');
    }

  });

  $('.map-loc4').click(function () {
    var mapStatus=$('.india-locationmap').css('display');
    if(mapStatus=='none')
    {
      $('.india-locationmap').fadeIn();
      $('.circle-india').show();
      $('.closemap').show();
    }
    else
    {
      $('.india-locationmap').fadeOut();
      $('.circle-india').hide();
      $('.closemap').hide();
    }
  });
  $(document).on('click', '.closemap', function () {
      $('.india-locationmap').fadeOut();
      $('.circle-india').hide();
      $(this).hide();
  });
  $(document).on('click', '.india-locationmap', function () {
      $(this).fadeOut();
      $('.circle-india').hide();
      $('.closemap').hide();
  });

});


function fixedFooter()
{
  $('body').css('min-height', $(window).height());
}
if($(window).width() < 1024){
	$(document).on('click', '.plistbox ul li', function () {
		//alert("hello")
	// $(".SliderwithOverlay .overlay-header").scrollTop(0);
	$("#enquiryform").css("margin-top",$("body").scrollTop());
	 $(".overlay-box").css("margin-top",(-1350 + $("body").scrollTop()));
	});
}
/*Overlay function*/
var animationIn, target, animationOut;
function overlayBox(popupID)
{
  target = $('#' + popupID)
  animationIn = target.attr('data-animation-in');
  animationOut = target.attr('data-animation-out');
  if (typeof (animationIn) == 'undefined' || animationIn === '(an empty string)' || animationIn === null || animationIn === '')
  {    
    animationIn = 'zoomIn';
  }
  if (typeof (animationOut) == 'undefined' || animationOut === '(an empty string)' || animationOut === null || animationOut === '')
  {
    animationOut = 'zoomOut';
  }
  $('body').append('<div class="overlay-bg"></div>')
  target.find('.overlay-header').append('<div class="closeBtn">X</div>');
  target.css('visibility', 'visible').css('display', 'block').find('.overlay-box').addClass('animated').addClass(animationIn);
  $(document).on('click', '.closeBtn', function () {
    $('.overlay').find('.overlay-box').removeClass('animated').removeClass(animationIn).addClass('animated ' + animationOut);
    $('body .overlay-bg').fadeOut(1000, function () {
      $(this).remove();
      $('.overlay').css('visibility', 'hidden').css('display', 'none').find('.overlay-box').removeClass('animated').removeClass(animationIn).removeClass(animationOut);
    });
  });
}

/*Overlay function end*/

var a = 0;
$(window).scroll(function() {

  var oTop = $('#counter').offset().top - window.innerHeight;
  if (a == 0 && $(window).scrollTop() > oTop) {
    $('.counter-value').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 2000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
            //alert('finished');
          }

        });
    });
    a = 1;
  }

});


if($(window).width() > 1024){
$(window).load(function(){
$('#carousel1').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider1'});
$('#slider1').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel1",start: function(slider){$('body').removeClass('loading');}});

$('#carousel2').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider2'});
$('#slider2').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel2",start: function(slider){$('body').removeClass('loading');}});

$('#carousel3').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider3'});
$('#slider3').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel3",start: function(slider){$('body').removeClass('loading');}});

$('#carousel4').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider4'});
$('#slider4').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel4",start: function(slider){$('body').removeClass('loading');}});

$('#carousel5').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider5'});
$('#slider5').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel5",start: function(slider){$('body').removeClass('loading');}});

$('#carousel6').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider6'});
$('#slider6').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel6",start: function(slider){$('body').removeClass('loading');}});

$('#carousel7').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider7'});
$('#slider7').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel7",start: function(slider){$('body').removeClass('loading');}});

$('#carousel8').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider8'});
$('#slider8').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel8",start: function(slider){$('body').removeClass('loading');}});

$('#carousel9').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider9'});
$('#slider9').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel9",start: function(slider){$('body').removeClass('loading');}});

$('#carousel10').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider10'});
$('#slider10').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel10",start: function(slider){$('body').removeClass('loading');}});

$('#carousel11').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider11'});
$('#slider11').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel11",start: function(slider){$('body').removeClass('loading');}});

$('#carousel12').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider12'});
$('#slider12').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel12",start: function(slider){$('body').removeClass('loading');}});

$('#carousel13').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider13'});
$('#slider13').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel13",start: function(slider){$('body').removeClass('loading');}});

$('#carousel14').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider14'});
$('#slider14').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel14",start: function(slider){$('body').removeClass('loading');}});

$('#carousel15').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider15'});
$('#slider15').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel15",start: function(slider){$('body').removeClass('loading');}});

$('#carousel16').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider16'});
$('#slider16').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel16",start: function(slider){$('body').removeClass('loading');}});

$('#carousel17').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider17'});
$('#slider17').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel17",start: function(slider){$('body').removeClass('loading');}});

$('#carousel18').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider18'});
$('#slider18').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel18",start: function(slider){$('body').removeClass('loading');}});

$('#carousel19').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider19'});
$('#slider19').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel19",start: function(slider){$('body').removeClass('loading');}});

$('#carousel20').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider20'});
$('#slider20').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel20",start: function(slider){$('body').removeClass('loading');}});

$('#carousel21').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider21'});
$('#slider21').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel21",start: function(slider){$('body').removeClass('loading');}});

$('#carousel22').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider22'});
$('#slider22').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel22",start: function(slider){$('body').removeClass('loading');}});

$('#carousel23').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider23'});
$('#slider23').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel23",start: function(slider){$('body').removeClass('loading');}});

$('#carousel24').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider24'});
$('#slider24').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel24",start: function(slider){$('body').removeClass('loading');}});

$('#carousel25').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider25'});
$('#slider25').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel25",start: function(slider){$('body').removeClass('loading');}});

$('#carousel26').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider26'});
$('#slider26').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel26",start: function(slider){$('body').removeClass('loading');}});

$('#carousel27').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider27'});
$('#slider27').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel27",start: function(slider){$('body').removeClass('loading');}});

$('#carousel28').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider28'});
$('#slider28').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel28",start: function(slider){$('body').removeClass('loading');}});

$('#carousel29').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider29'});
$('#slider29').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel29",start: function(slider){$('body').removeClass('loading');}});

$('#carousel30').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider30'});
$('#slider30').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel30",start: function(slider){$('body').removeClass('loading');}});

$('#carousel31').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider31'});
$('#slider31').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel31",start: function(slider){$('body').removeClass('loading');}});

$('#carousel32').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider32'});
$('#slider32').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel32",start: function(slider){$('body').removeClass('loading');}});

$('#carousel33').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider33'});
$('#slider33').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel33",start: function(slider){$('body').removeClass('loading');}});

$('#carousel34').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider34'});
$('#slider34').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel34",start: function(slider){$('body').removeClass('loading');}});

$('#carousel35').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider35'});
$('#slider35').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel35",start: function(slider){$('body').removeClass('loading');}});

$('#carousel36').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider36'});
$('#slider36').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel36",start: function(slider){$('body').removeClass('loading');}});

$('#carousel37').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider37'});
$('#slider37').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel37",start: function(slider){$('body').removeClass('loading');}});

$('#carousel38').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider38'});
$('#slider38').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel38",start: function(slider){$('body').removeClass('loading');}});

$('#carousel39').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider39'});
$('#slider39').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel39",start: function(slider){$('body').removeClass('loading');}});

$('#carousel40').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false,itemWidth: 171,itemMargin: 0,asNavFor: '#slider40'});
$('#slider40').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel40",start: function(slider){$('body').removeClass('loading');}});

});
}
		
if($(window).width() < 1024){
$(window).load(function(){
$('#carousel1').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider1'});
$('#slider1').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel1",start: function(slider){$('body').removeClass('loading');}});

$('#carousel2').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider2'});
$('#slider2').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel2",start: function(slider){$('body').removeClass('loading');}});

$('#carousel3').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider3'});
$('#slider3').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel3",start: function(slider){$('body').removeClass('loading');}});

$('#carousel4').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider4'});
$('#slider4').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel4",start: function(slider){$('body').removeClass('loading');}});

$('#carousel5').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider5'});
$('#slider5').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel5",start: function(slider){$('body').removeClass('loading');}});

$('#carousel6').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider6'});
$('#slider6').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel6",start: function(slider){$('body').removeClass('loading');}});

$('#carousel7').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider7'});
$('#slider7').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel7",start: function(slider){$('body').removeClass('loading');}});

$('#carousel8').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider8'});
$('#slider8').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel8",start: function(slider){$('body').removeClass('loading');}});

$('#carousel9').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider9'});
$('#slider9').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel9",start: function(slider){$('body').removeClass('loading');}});

$('#carousel10').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider10'});
$('#slider10').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel10",start: function(slider){$('body').removeClass('loading');}});

$('#carousel11').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider11'});
$('#slider11').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel11",start: function(slider){$('body').removeClass('loading');}});

$('#carousel12').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider12'});
$('#slider12').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel12",start: function(slider){$('body').removeClass('loading');}});

$('#carousel13').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider13'});
$('#slider13').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel13",start: function(slider){$('body').removeClass('loading');}});

$('#carousel14').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider14'});
$('#slider14').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel14",start: function(slider){$('body').removeClass('loading');}});

$('#carousel15').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider15'});
$('#slider15').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel15",start: function(slider){$('body').removeClass('loading');}});

$('#carousel16').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider16'});
$('#slider16').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel16",start: function(slider){$('body').removeClass('loading');}});

$('#carousel17').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider17'});
$('#slider17').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel17",start: function(slider){$('body').removeClass('loading');}});

$('#carousel18').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider18'});
$('#slider18').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel18",start: function(slider){$('body').removeClass('loading');}});

$('#carousel19').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider19'});
$('#slider19').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel19",start: function(slider){$('body').removeClass('loading');}});

$('#carousel20').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider20'});
$('#slider20').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel20",start: function(slider){$('body').removeClass('loading');}});

$('#carousel21').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider21'});
$('#slider21').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel21",start: function(slider){$('body').removeClass('loading');}});

$('#carousel22').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider22'});
$('#slider22').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel22",start: function(slider){$('body').removeClass('loading');}});

$('#carousel23').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider23'});
$('#slider23').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel23",start: function(slider){$('body').removeClass('loading');}});

$('#carousel24').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider24'});
$('#slider24').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel24",start: function(slider){$('body').removeClass('loading');}});

$('#carousel25').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider25'});
$('#slider25').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel25",start: function(slider){$('body').removeClass('loading');}});

$('#carousel26').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider26'});
$('#slider26').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel26",start: function(slider){$('body').removeClass('loading');}});

$('#carousel27').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider27'});
$('#slider27').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel27",start: function(slider){$('body').removeClass('loading');}});

$('#carousel28').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider28'});
$('#slider28').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel28",start: function(slider){$('body').removeClass('loading');}});

$('#carousel29').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider29'});
$('#slider29').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel29",start: function(slider){$('body').removeClass('loading');}});

$('#carousel30').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider30'});
$('#slider30').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel30",start: function(slider){$('body').removeClass('loading');}});

$('#carousel31').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider31'});
$('#slider31').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel31",start: function(slider){$('body').removeClass('loading');}});

$('#carousel32').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider32'});
$('#slider32').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel32",start: function(slider){$('body').removeClass('loading');}});

$('#carousel33').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider33'});
$('#slider33').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel33",start: function(slider){$('body').removeClass('loading');}});

$('#carousel34').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider34'});
$('#slider34').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel34",start: function(slider){$('body').removeClass('loading');}});

$('#carousel35').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider35'});
$('#slider35').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel35",start: function(slider){$('body').removeClass('loading');}});

$('#carousel36').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider36'});
$('#slider36').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel36",start: function(slider){$('body').removeClass('loading');}});

$('#carousel37').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider37'});
$('#slider37').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel37",start: function(slider){$('body').removeClass('loading');}});

$('#carousel38').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider38'});
$('#slider38').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel38",start: function(slider){$('body').removeClass('loading');}});

$('#carousel39').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider39'});
$('#slider39').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel39",start: function(slider){$('body').removeClass('loading');}});

$('#carousel40').flexslider({animation: "slide",controlNav: false,animationLoop: false,slideshow: false, itemWidth: 100,itemMargin: 0,asNavFor: '#slider40'});
$('#slider40').flexslider({animation: "slide",controlNav:false,animationLoop:false,slideshow:false,sync: "#carousel40",start: function(slider){$('body').removeClass('loading');}});

});
}